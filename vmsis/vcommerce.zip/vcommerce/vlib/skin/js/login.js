$(document).ready(function() {  
  $('.errorlist').addClass('alert alert-danger');
  $('input').addClass('form-control');
  $('#id_username').attr('placeholder','Usuário');  
  $('#id_password').attr('placeholder','Senha');
});
